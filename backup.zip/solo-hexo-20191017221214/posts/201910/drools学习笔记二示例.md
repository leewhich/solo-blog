title: drools学习笔记（二）示例
date: '2019-10-15 09:27:52'
updated: '2019-10-15 22:41:14'
tags: [drools]
permalink: /articles/2019/10/15/1571102872058.html
---
![](https://img.hacpai.com/bing/20190224.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## **项目结构**
![drools2.png](https://img.hacpai.com/file/2019/10/drools2-336f2ead.png)

## **示例**
* 使用kmodule的方式调用drools 创建文件：/resources/META-INF/kmodule.xml
    
    ```
    <?xml version="1.0" encoding="UTF-8"?>
    <kmodule xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
             xmlns="http://www.drools.org/xsd/kmodule">
        <kbase name="HonestPoliticianKB" packages="com.xu.drools.rule.honestpolitician">
            <ksession name="HonestPoliticianKS"/>
        </kbase>
    </kmodule>
    
    ```
    
* rule  【drl文件HonestPolitician.drl】
    
    ```
    package com.xu.drools                 //package指定命名空间:com.xu.drools
    
    import com.xu.drools.bean.Politician; //import要使用的对象:Politician
    import com.xu.drools.bean.Hope;       //import要使用的对象:Hope
    
    rule "We have an honest Politician"   //rule,定义规则:We have an honest Politician
        salience 10                       //salience，属性部分，定义优先级:10
        when
            exists( Politician( honest == true ) ) //exists,条件部分-LHS，定义当前规则的条件：存在honest==true的Politician
        then
            insertLogical( new Hope() );  //insertLogical,结果部分-RHS，定义规则满足后执行的操作：往当前workingMemory中插入一个新的Hope对象
    end                                   //规则结束
    
    rule "Hope Lives"
        salience 10
        when
            exists( Hope() )
        then
            System.out.println("Hurrah!!! Democracy Lives");
    end
    
    rule "Hope is Dead"
        when
            not( Hope() )                 //not,不存在：不存在Hope对象
        then
            System.out.println( "We are all Doomed!!! Democracy is Dead" );
    end
    
    rule "Corrupt the Honest"
        when
            politician : Politician( honest == true )
            exists( Hope() )
        then
            System.out.println( "I'm an evil corporation and I have corrupted " + politician.getName() );
            modify( politician ) {        //modify,修改：修改politician的Honest为false
                setHonest( false )
            }
    end
    
    ```

* bean 【Politician】
    
    ```	
	package com.xu.drools.bean;
	
	public class Politician {
	    private String  name;
	
	    private boolean honest;
	
	    public Politician() {
	
	    }
	
	    public Politician(String name,
	            boolean honest) {
	        super();
	        this.name = name;
	        this.honest = honest;
	    }
	
	    public boolean isHonest() {
	        return honest;
	    }
	
	    public void setHonest(boolean honest) {
	        this.honest = honest;
	    }
	
	    public String getName() {
	        return name;
	    }
	}

    ```
* 数据的输入
    
    ```
     public static void main(final String[] args) {
        KieContainer kc = KieServices.Factory.get().getKieClasspathContainer();
        System.out.println(kc.verify().getMessages().toString());
        execute( kc );
    }
    
    public static void execute( KieContainer kc ) {
        KieSession ksession = kc.newKieSession("HonestPoliticianKS");
    
        final Politician p1 = new Politician( "President of Umpa Lumpa", true );
        final Politician p2 = new Politician( "Prime Minster of Cheeseland", true );
        final Politician p3 = new Politician( "Tsar of Pringapopaloo", true );
        final Politician p4 = new Politician( "Omnipotence Om", true );
    
        ksession.insert( p1 );
        ksession.insert( p2 );
        ksession.insert( p3 );
        ksession.insert( p4 );
    
        ksession.fireAllRules();
    
        ksession.dispose();
    }
    
    ```
    
* rule的执行顺序
![drools.png](https://img.hacpai.com/file/2019/10/drools-088ce335.png)



* 执行结果
```
Hurrah!!! Democracy Lives 【使用模式`exists`，则规则将只激活最多一次，而不管在工作存储器中存在与存在模式中的条件匹配的数据量】
I'm an evil corporation and I have corrupted President of Umpa Lumpa
I'm an evil corporation and I have corrupted Prime Minster of Cheeseland
I'm an evil corporation and I have corrupted Tsar of Pringapopaloo
I'm an evil corporation and I have corrupted Omnipotence Om
We are all Doomed!!! Democracy is Dead
```
## Drools应用

[](https://github.com/MyHerux/drools-springboot/blob/master/Drools-Use.md#动态规则)

### 动态规则

[](https://github.com/MyHerux/drools-springboot/blob/master/Drools-Use.md#动态获取kiesession)

#### 动态获取KieSession

```
    public KieSession getKieSession(String rules) {
        KieServices kieServices = KieServices.Factory.get();
        KieFileSystem kfs = kieServices.newKieFileSystem();
        kfs.write("src/main/resources/rules/rules.drl", rules.getBytes());
        KieBuilder kieBuilder = kieServices.newKieBuilder(kfs).buildAll();
        Results results = kieBuilder.getResults();
        if (results.hasMessages(org.kie.api.builder.Message.Level.ERROR)) {
            System.out.println(results.getMessages());
            throw new BusinessException(300003,results.getMessages().toString(),4);
        }
        KieContainer kieContainer = kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
        KieBase kieBase = kieContainer.getKieBase();

        return kieBase.newKieSession();
    }

```

[](https://github.com/MyHerux/drools-springboot/blob/master/Drools-Use.md#激活规则)

#### 激活规则

```
    KieSession kieSession = rulesService.getKieSession(rule);
    Gson gson = new Gson();
    Person person = gson.fromJson(json, Person.class);
    kieSession.insert(person);
    kieSession.fireAllRules();
    kieSession.dispose();

```

[](https://github.com/MyHerux/drools-springboot/blob/master/Drools-Use.md#决策表)

### 决策表

[](https://github.com/MyHerux/drools-springboot/blob/master/Drools-Use.md#将文件翻译为drl文件)

#### 将文件翻译为drl文件

```
    public String getRuleTable() {
        //把excel翻译成drl文件
        SpreadsheetCompiler compiler = new SpreadsheetCompiler();
        String rules = compiler.compile(ResourceFactory.newClassPathResource(RULES_PATH + File.separator + "rule.xlsx", "UTF-8"), "rule-table");
        System.out.println(rules);
        return rules;
    }

```

[](https://github.com/MyHerux/drools-springboot/blob/master/Drools-Use.md#将文件流翻译为drl文件)

#### 将文件流翻译为drl文件

```
    public String getRuleTable(InputStream inputStream) {
        //把excel翻译成drl文件
        SpreadsheetCompiler compiler = new SpreadsheetCompiler();
        String rules = compiler.compile(ResourceFactory.newInputStreamResource(inputStream, "UTF-8"), "rule-table");
        logger.info("get rule from xls:" + rules);
        return rules;
    }

```

