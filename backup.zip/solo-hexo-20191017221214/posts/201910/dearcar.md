title: dear car
date: '2019-10-15 22:45:12'
updated: '2019-10-15 22:45:12'
tags: [car]
permalink: /articles/2019/10/15/1571150711959.html
---
![](https://img.hacpai.com/bing/20180524.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 刚洗完澡的时候![IMG20191015212231.jpg](https://img.hacpai.com/file/2019/10/IMG20191015212231-713a6ced.jpg)![IMG20191015212301.jpg](https://img.hacpai.com/file/2019/10/IMG20191015212301-d5fb37e6.jpg)
![IMG20191015212250.jpg](https://img.hacpai.com/file/2019/10/IMG20191015212250-3f058c81.jpg)


