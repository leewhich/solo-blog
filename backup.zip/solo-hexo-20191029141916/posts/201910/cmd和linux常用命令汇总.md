title: cmd和linux常用命令汇总
date: '2019-10-15 13:18:54'
updated: '2019-10-15 13:18:54'
tags: [linux, cmd, 常用命令]
permalink: /articles/2019/10/15/1571116734151.html
---
## CMD

查看端口占用 netstat -aon|findstr "49157"

删除进程号 taskkill /f /pid 19656

## Liux 常用的命令

查询监听端口号 netstat -nlp |grep LISTEN

停止所有docker容器 docker stop $(docker ps -aq)

删除所有docker容器 docker rm $(docker ps -aq)

删除所有docker镜像 docker rmi $(docker images -q)

查询docker实时日志 docker logs -f -t --tail 条数 容器ID/容器名

进入容器 docker exec -it mysql5.7.26 /bin/bash

nginx命令

start ngnix

nginx -s stop/reload

拷贝容器中的配置文件

docker cp fa752aca762:/etc/nginx/conf.d/default.conf .

复制回去

docker cp default.conf 5fb90ca02bf9:/etc/nginx/conf.d/default.conf
