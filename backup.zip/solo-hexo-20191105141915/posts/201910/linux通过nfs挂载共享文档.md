title: linux通过nfs挂载共享文档
date: '2019-10-15 13:16:40'
updated: '2019-10-17 11:50:35'
tags: [linux, nfs, 共享文档]
permalink: /articles/2019/10/15/1571116600574.html
---
## linux挂载共享文档
#### 参考 https://blog.csdn.net/hello5orld/article/details/11526165

### 一.服务器端（即要共享的电脑）

假设服务器端的地址是：192.168.1.140

下载：yum命令：yum install nfs* portmap -y    //NFS与RPC同时安装的yum命令

关闭防火墙：systemctl stop firewalld

禁用selinux：vi /etc/sysconfig/selinux      [selinux](https://baike.baidu.com/item/SELinux/8865268?fr=aladdin)：新手最好禁止

将SELINUX的状态改为：display。保存退出即可

配置：nfs主要配置文件为：/etc/exports

vi /etc/exports

添加：/filevb/yzn 192.168.1.115/24(rw,sync)  

其中/share 是需要共享的文件夹，共享的文件就存放在/share文件夹中，而*指的是让哪个用户连接ps：192.168.1.121 而括号里面的则是各种参数

创建共享文件夹 :mkdir /share

给文件夹授权 ：chmod 766 /share

把NFS设为开机自启：systemctl enable nfs

开启NFS服务：systemctl start nfs

将RPC设为开机自启：systemctl enable rpcbind

开启RPC服务：systemctl start rpcbind

---你的可以通过systemctl status nfs 等查看状态

使用chown命令挂载文件夹/share :chown nfsnobody.nfsnobody /share【这里用户、用户组写自己的】

输入“exportfs”查看本机的共享文件系统，如果有则代表成功

### 二.客户端（指查看共享文件夹的电脑）

1.安装NFS与RPC并将它们设为开机自启与启动

2.关闭防火墙，禁止selinux

3.挂载共享的nfs系统：mount -o nolock -t nfs 192.168.199.121:/filevb /opt/dingding/share

4.查看是否成功：mount |grep share

192.168.199.121:/filevb/yzn on /opt/dingding/share type nfs4 (rw,relatime,vers=4.1,rsize=524288,wsize=524288,namlen=255,hard,proto=tcp,timeo=600,retrans=2,sec=sys,clientaddr=192.168.199.115,local_lock=none,addr=192.168.199.121)

5.把共享目录写入系统挂载文件：vi /etc/fstab

追加：192.168.1.140:/share /media nfs4 defaults 0 0

### 三.测试

1.在服务器的共享目录（/share）中添加一个测试文件：test1

2.在客户端中查看文件并删除test1，同时添加test2

3.在服务器中看test2是否存在且test1 删除成功

### 四、关闭共享
umount /opt/dingding/share

如果报错，可能是因为目录被占用了，需要kill

yum install psmisc

fuser -m /opt/dingding/share

kill -9 xxxxx
