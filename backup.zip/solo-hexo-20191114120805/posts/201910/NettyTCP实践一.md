title: Netty-TCP实践（一）
date: '2019-10-15 14:55:31'
updated: '2019-10-15 14:55:31'
tags: [Netty, TCP]
permalink: /articles/2019/10/15/1571122531473.html
---
### 是什么？

Netty是一个异步事件驱动的网络应用框架，用于快速开发可维护的高性能服务器和客户端。

### 怎么用？

pom添加依赖
```
<dependency>

<groupId>io.netty</groupId>

<artifactId>netty-all</artifactId>

<version>4.1.24.Final</version>

</dependency>
```
### Netty客户端
handler可以自己封装一个类，然后注入它的对象。该类继承

ChannelInitializer<SocketChannel>，重写initChannel方法，该方法可以添加自定义的handler

自定义Handler

pipeline.addLast("serverChannelHandler", serverChannelHandler);

自定义handle继承SimpleChannelInboundHandler<Object>，重写channelRead0方法，该方法可以实现接收服务器消息的功能。

还可以重写ChannelInboundHandlerAdapter 中的方法：

1、第一次连接成功的进入的

channelActive(ChannelHandlerContext ctx)

```
public static void main(String[] args) throws InterruptedException {
    Bootstrap bootstrap = new Bootstrap();
    NioEventLoopGroup group = new NioEventLoopGroup();

    bootstrap.group(group)
            .channel(NioSocketChannel.class)
            .handler(new ChannelInitializer<Channel>() {//设置通道处理者
                @Override
                protected void initChannel(Channel ch) {
                    ch.pipeline().addLast(new StringEncoder());
                }
            });

    Channel channel = bootstrap.connect("127.0.0.1", 7000).channel();

    while (true) {
        channel.writeAndFlush(new Date() + ": hello world!");
        Thread.sleep(2000);
    }
}
```

### 服务端
handler可以自己封装一个类，然后注入它的对象。该类继承ChannelInitializer<SocketChannel>，重写initChannel方法，该方法可以添加自定义的handler

自定义Handler

pipeline.addLast("serverChannelHandler", serverChannelHandler);

自定义handle继承SimpleChannelInboundHandler<Object>，重写channelRead0方法，该方法可以实现接收客户端消息的功能。

```
public static void main(String[] args) {

ServerBootstrap serverBootstrap = new ServerBootstrap();

//boss事件轮询线程组

// 处理Accept连接事件的线程，这里线程数设置为1即可，netty处理链接事件默认为单线程，过度设置反而浪费cpu资源

NioEventLoopGroup boos = new NioEventLoopGroup();

// worker事件轮询线程组

//处理hadnler的工作线程，其实也就是处理IO读写 。线程数据默认为 CPU 核心数乘以2

NioEventLoopGroup worker = new NioEventLoopGroup();

serverBootstrap

//组配置，初始化ServerBootstrap的线程组

.group(boos, worker)

//构造channel通道工厂//bossGroup的通道，只是负责连接

.channel(NioServerSocketChannel.class)

//设置通道处理者ChannelHandler///workerGroup的处理器

.childHandler(new ChannelInitializer<NioSocketChannel>() {

protected void initChannel(NioSocketChannel ch) {

ch.pipeline().addLast(new StringDecoder());

//添加自定义的Handler

ch.pipeline().addLast(new SimpleChannelInboundHandler<String>() {

//重写抽象方法

@Override

protected void channelRead0(ChannelHandlerContext ctx, String msg) {

  

//接收到消息后进行的操作

System.out.println(msg);

ctx.channel().writeAndFlush(" hello im received you message"+msg).syncUninterruptibly();//绑定端口，开启监听，同步等待

}

//可重写的方法

//第一次连接成功后进入的方法

@Override

public void channelActive(){};

//心跳机制，超时处理

@Override

public void userEventTriggered(){}

});

}

})

//绑定端口，开启监听，同步等待

.bind(7000)

//.syncUninterruptibly();

}
```

