title: mysql5.7主从复制实践
date: '2019-10-15 13:57:40'
updated: '2019-10-15 14:28:18'
tags: [mysql, linux, 主从复制]
permalink: /articles/2019/10/15/1571119060644.html
---
### 原理：基于日志log-bin  
  
### 配置：主windows 5.7.26 +从Linux 5.7.26
### 一、准备工作

执行创建数据的命令：
```
UTF8：CREATE DATABASE`iot_testing_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
```
查看数据库编码：
```
show variables like 'char%';
```
1.导出整个数据库
```
mysqldump -u 用户名 -p 数据库名 > 导出的文件名

mysqldump -u dbuser -p dbname > dbname.sql
```
  
2.导出一个表
```
mysqldump -u 用户名 -p 数据库名 表名> 导出的文件名

mysqldump -u dbuser -p dbname users> dbname_users.sql
```
  
3.导出一个数据库结构
```
mysqldump -u dbuser -p -d --add-drop-table dbname >d:/dbname_db.sql

-d 没有数据 --add-drop-table 在每个create语句之前增加一个drop table
```
  
4.导入数据库
```
然后使用source命令，后面参数为脚本文件(如这里用到的.sql)

mysql>source d:/dbname.sql
```

### 主windows mysql配置
```
[client]

port=3306

default-character-set=utf8

[mysqld]

# 设置为自己MYSQL的安装目录

basedir=C:\\mysql-5.7.26-winx64

# 设置为MYSQL的数据目录

datadir=C:\\mysql-5.7.26-winx64\\data

port=3306

character_set_server=utf8

sql_mode=NO_ENGINE_SUBSTITUTION,NO_AUTO_CREATE_USER

#开启查询缓存

explicit_defaults_for_timestamp=true

skip-grant-tables //不用密码登录

  

#服务器id不固定，整数即可

server-id=110

  

#同步日志的文件存放路径

log-bin=C:\\mysql-5.7.26-winx64\\mysql-log

  

# 使binlog在每N次binlog写入后与硬盘 同步

sync-binlog=1

  

#备份哪些些数据库的二进制日志

binlog-do-db=iot_testing_db

  

# 不需要同步的数据库

binlog-ignore-db=mysql

# Error Logging.

log-error="data.err"
```

### MySQL用到的命令

#### * 1、 启动/关闭

```
net stop/start mysql;（管理员CMD）
```
  
####  * 2、开启远程访问
```
登录mysql，输入mysql -uroot -p

切换到mysql数据库，输入命令use mysql;

开启远程连接，输入命令GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '密码' WITH GRANT OPTION;

刷新权限，命令为：FLUSH PRIVILEGES;

重启mysql服务
```
#### * 3、显示主库的参数
```
查看是否开启日志 show binary logs;
#同步日志的文件存放路径 log-bin=C:\\mysql-5.7.26-winx64\\mysql-log
```
![mysql001.png](https://img.hacpai.com/file/2019/10/mysql001-13ed4cee.png)
```
查看主库状态 show master status ;

File 同步日志文件名  
  
Position 同步文件位置  
  
Binlog_Do_DB 要同步的数据库名  
  
Binlog_Ignore_DB 不同步的数据库名
```
![mysql002.png](https://img.hacpai.com/file/2019/10/mysql002-91b575d8.png)

### 从linux mysql配置
```
[client]

port = 3306

default-character-set=utf8

socket=/tmp/mysql.sock

[mysqld]

bind-address = 0.0.0.0

user=root

# 一般配置选项

basedir = /usr/soft/mysql

datadir = /usr/soft/mysql/data

port = 3306

character-set-server=utf8

default_storage_engine = InnoDB

#服务器id

server-id=114

#要从主机同步的库

replicate-do-db=iot_testing_db

sql_mode=STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION

expire_logs_days=14 #过期时间

sync_binlog=1

log_bin=/data/mysql/mysql-bin #同步日志位置

relay_log_recovery=1

#socket=/tmp/mysql.sock

max_connections=1000

max_user_connections=500

log_error=/data/mysql/mysql-error.log

#错误日志位置为/data/mysql/mysql-error.log
```
#### * 1、启动

service mysql {start|stop|restart|reload|force-reload|status}

或者

/etc/rc.d/init.d/mysqld start/stop/status

#### * 2、配置（取master的参数）

change master to master_host='192.168.199.110',（master_port=3306,）master_user='root',master_password='123456', master_log_file='mysql-log.000005',master_log_pos=14537;

#### * 3、放过错误信息

set global sql_slave_skip_counter=1;

stop slave;

start slave;

#### * 4、查询从库状态

show slave status \G;

**如图显示则连接成功！**
![mysql003.png](https://img.hacpai.com/file/2019/10/mysql003-9719eeee.png)

