title: k8s部署实践   (二) k8s-dashboard
date: '2019-11-13 17:00:21'
updated: '2019-11-13 17:07:42'
tags: [k8s, k8s-dashboard]
permalink: /articles/2019/11/13/1573635621450.html
---
### 前提条件
已经搭建好k8s集群
### 步骤1 下载并执行kubernetes-dashboard.yaml
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v1.10.1/src/deploy/recommended/kubernetes-dashboard.yaml
#### ps:
	可能会遇到kubernetes-dashboard 镜像pull失败的情况，我们手动去node节点下载国内的镜像，并手动tag。当然最好就是用自己的harbor仓库。
    docker pull mirrorgooglecontainers/kubernetes-dashboard-amd64:v1.10.1
    docker tag mirrorgooglecontainers/kubernetes-dashboard-amd64:v1.10.1 k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1
    docker rmi mirrorgooglecontainers/kubernetes-dashboard-amd64:v1.10.1

### 步骤2 查看状态
kubectl get pods --all-namespaces -o wide
kubectl describe pod -n kube-system kubernetes-dashboard-xxxxxxxx -v=10

### 步骤3 编辑service 将类型改为NodePort（采用NodePort方式，还有Ingress等方式）
kubectl edit service  kubernetes-dashboard --namespace=kube-system
```
apiVersion: v1
kind: Service
metadata:
  annotations:
    kubectl.kubernetes.io/last-applied-configuration: |
      {"apiVersion":"v1","kind":"Service","metadata":{"annotations":{},"labels":{"k8s-app":"kubernetes-dashboard"},"name":"kubernetes-dashboard","namespace":"kube-system"},"spec":{"ports":[{"port":443,"targetPort":8443}],"selector":{"k8s-app":"kubernetes-dashboard"}}}
  creationTimestamp: "2019-11-13T07:49:18Z"
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard
  namespace: kube-system
  resourceVersion: "1176"
  selfLink: /api/v1/namespaces/kube-system/services/kubernetes-dashboard
  uid: 007c861e-21bf-41c3-b229-42392d3a5ac0
spec:
  clusterIP: 10.109.180.8
  externalTrafficPolicy: Cluster
  ports:
  - nodePort: 31732    #这里设置对外暴露的Ip
    port: 443
    protocol: TCP
    targetPort: 8443
  selector:
    k8s-app: kubernetes-dashboard
  sessionAffinity: None
  type: NodePort    #由默认的ClusterIp改为NodePort
status:
  loadBalancer: {}
```
查看Service 可以看到已经将31732端口暴露
kubectl get service --namespace=kube-system
```
[root@k8s-master k8syaml]# kubectl get service --namespace=kube-system
NAME                   TYPE        CLUSTER-IP     EXTERNAL-IP   PORT(S)                  AGE
kube-dns               ClusterIP   10.96.0.10     <none>        53/UDP,53/TCP,9153/TCP   67m
kubernetes-dashboard   NodePort    10.109.180.8   <none>        443:31732/TCP            63
```
### 步骤4 创建管理员账户
```
#vi admin-token.yaml
#内容如下

kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1beta1
metadata:
  name: admin
  annotations:
    rbac.authorization.kubernetes.io/autoupdate: "true"
roleRef:
  kind: ClusterRole
  name: cluster-admin
  apiGroup: rbac.authorization.k8s.io
subjects:
- kind: ServiceAccount
  name: admin
  namespace: kube-system
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: admin
  namespace: kube-system
  labels:
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile

```
并执行kubectl apply -f admin-token.yaml
####  步骤5 生成Token
```
kubectl describe secret/$(kubectl get secret -nkube-system |grep admin|awk '{print $1}') -nkube-system
##开启DNS转发
iptables -P FORWARD ACCEPT
```
#### 步骤5 访问测试
https://materIp:NodePort/
填写生成的Token
效果如下  
![k8sdashboard.png](https://img.hacpai.com/file/2019/11/k8sdashboard-18a26e6e.png)
