title: k8s部署实践（一）主节点的高可用
date: '2019-11-20 09:54:14'
updated: '2019-11-20 09:54:50'
tags: [keepalived, haproxy, HA, 高可用]
permalink: /articles/2019/11/20/1574214854230.html
---
![](https://img.hacpai.com/bing/20190125.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

keepalived+haproxy 实现 kube-apiserver VIP 高可用和负载均衡
![keepalinedhaproxy.png](https://img.hacpai.com/file/2019/11/keepalinedhaproxy-743aa91f.png)

