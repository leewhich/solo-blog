title: Netty-UDP实践（一）
date: '2019-10-15 14:50:45'
updated: '2019-10-15 14:51:35'
tags: [Netty, UDP]
permalink: /articles/2019/10/15/1571122245722.html
---
#### 服务端(发送消息)
```
@Service
public class NettyService {
    private static Logger logger = LoggerFactory.getLogger(NettyService.class);
    @Value("${server.udpport}")
    private int port;
    @Autowired
    private NBServerHandler nBServerHandler;
    /**
     * 启动
     * @throws Exception 
     * @throws Exception 
     */
    @Async
    public void start(){
        logger.info("start udp server port:{}",port);
        EventLoopGroup group = new NioEventLoopGroup(20);
        try {
            Bootstrap bootstrap = new Bootstrap();
            bootstrap.group(group)
                    .channel(NioDatagramChannel.class)
                    .option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
                    .option(ChannelOption.SO_BROADCAST, true)
                    .handler(nBServerHandler);
           }
            Channel channel = bootstrap.bind(port).channel();
            //阻塞线程
            //channel.closeFuture().await();
            //非阻塞，添加监听器，完成后IO线程通知监听器
            channel.closeFuture().addListener((ChannelFutureListener) future -> {
            });
            logger.info("start udp server success");
        } catch (Exception e) {
            logger.error("start udp server error: {}", e.getMessage());
            e.printStackTrace();
        } finally {
            group.shutdownGracefully();
        }
```
* await()与addListener（）

await()会阻塞线程，不要在ChannelHandler中调用await(),如果调用，正在等待的IO操作可能不会完成，形成死锁。

而addListener（）不会阻塞线程，会添加一个监听器，完成后IO线程通知监听器。

#### 客户端（接收消息）
继承SimpleChannelInboundHandler<DatagramPacket>

重写channelRead0(ChannelHandlerContext ctx, DatagramPacket packet)
```
public class NBServerHandler extends SimpleChannelInboundHandler<DatagramPacket> {

    private static Logger logger = LoggerFactory.getLogger(NBServerHandler.class);

    @Autowired
    ProductService productService;

    @Override
    public void channelRead0(ChannelHandlerContext ctx, DatagramPacket packet) throws Exception {
        // 读取收到的数据
        String ip = packet.sender().getHostString();
        String port = String.valueOf(packet.sender().getPort());
        String key = ip+":"+port;
        ByteBuf buf = (ByteBuf) packet.copy().content();
        byte[] req = new byte[buf.readableBytes()];
        buf.readBytes(req);
        StringBuilder stringBuilder = new StringBuilder("");
        for (int i = 0; i < req.length; i++) {
            int v = req[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        String body = stringBuilder.toString();
        logger.info("接收到客户端的16进制请求数据:{}", body);
//        logger.info("接收到数据:{}", HexConverter.toStringHex(body));
        /**
         * TODO  分装消息后放入 MQ
         */
        //String message="7b22696f744964223a22347a3831395651486b3656534c6d6d424a66726630303130376565323030222c2270726f647563744b6579223a2231323334353536353534222c226465766963654e616d65223a226465766963654e616d6531323334222c22676d74437265617465223a313531303739393637303037342c2264657669636554797065223a22416d6d65746572222c226974656d73223a7b22506f776572223a7b2276616c7565223a226f6e222c2274696d65223a313531303739393637303037347d2c22506f736974696f6e223a7b2274696d65223a313531303239323639373437302c2276616c7565223a7b226c61746974756465223a33392e392c226c6f6e676974756465223a3131362e33387d7d7d7d";
     //   productService.save(body);
        //处理udp请求
//        orderHandler.handlerUdp(body.toLowerCase(), ctx, packet, ip, port);
    }
    

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        ctx.flush();//刷新后才将数据发出到SocketChannel
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
            throws Exception {
        cause.printStackTrace();
        ctx.close();
    }
}
```
