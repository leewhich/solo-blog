title: k8s部署实践（一）搭建
date: '2019-10-15 10:57:08'
updated: '2019-11-07 16:03:53'
tags: [kubenetes, k8s, Docker]
permalink: /articles/2019/10/15/1571108228226.html
---
![](https://img.hacpai.com/bing/20181124.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

![k8s.png](https://img.hacpai.com/file/2019/10/k8s-ec020da2.png)
	Kubernetes 项目的架构，跟它的原型项目 Borg 非常类似，都由 Master 和 Node 两种节点组成，而这两种角色分别对应着控制节点和计算节点。其中，控制节点，即 Master 节点，由三个紧密协作的独立组件组合而成，它们分别是负责 API 服务的 kube-apiserver、负责调度的 kube-scheduler，以及负责容器编排的 kube-controller-manager。整个集群的持久化数据，则由 kube-apiserver 处理后保存在 Etcd 中。
	而计算节点上最核心的部分，则是一个叫作 `kubelet `的组件。在 Kubernetes 项目中，kubelet 主要负责同容器运行时（比如 Docker 项目）打交道。而这个交互所依赖的，是一个称作 CRI（Container Runtime Interface）的远程调用接口，这个接口定义了容器运行时的各项核心操作，比如：启动一个容器需要的所有参数。这也是为何，Kubernetes 项目并不关心你部署的是什么容器运行时、使用的什么技术实现，只要你的这个容器运行时能够运行标准的容器镜像，它就可以通过实现 CRI 接入到 Kubernetes 项目当中。而具体的容器运行时，比如 Docker 项目，则一般通过 OCI 这个容器运行时规范同底层的 Linux 操作系统进行交互，即：把 CRI 请求翻译成对 Linux 操作系统的调用（操作 Linux Namespace 和 Cgroups 等）。
	比如，Kubernetes 项目对容器间的“访问”进行了分类，首先总结出了一类非常常见的“紧密交互”的关系，即：这些应用之间需要非常频繁的交互和访问；又或者，它们会直接通过本地文件进行信息交换。在常规环境下，这些应用往往会被直接部署在同一台机器上，通过 Localhost 通信，通过本地磁盘目录交换文件。而在 Kubernetes 项目中，这些容器则会被划分为一个“Pod”，Pod 里的容器共享同一个 Network Namespace、同一组数据卷，从而达到高效率交换信息的目的。Pod 是 Kubernetes 项目中最基础的一个对象，源自于 Google Borg 论文中一个名叫 Alloc 的设计。在后续的章节中，我们会对 Pod 做更进一步地阐述。而对于另外一种更为常见的需求，比如 Web 应用与数据库之间的访问关系，Kubernetes 项目则提供了一种叫作“Service”的服务。像这样的两个应用，往往故意不部署在同一台机器上，这样即使 Web 应用所在的机器宕机了，数据库也完全不受影响。可是，我们知道，对于一个容器来说，它的 IP 地址等信息不是固定的，那么 Web 应用又怎么找到数据库容器的 Pod 呢？所以，Kubernetes 项目的做法是给 Pod 绑定一个 Service 服务，而 Service 服务声明的 IP 地址等信息是“终生不变”的。这个 Service 服务的主要作用，就是作为 Pod 的代理入口（Portal），从而代替 Pod 对外暴露一个固定的网络地址。这样，对于 Web 应用的 Pod 来说，它需要关心的就是数据库 Pod 的 Service 信息。不难想象，Service 后端真正代理的 Pod 的 IP 地址、端口等信息的自动更新、维护，则是 Kubernetes 项目的职责。
### 项目背景
本次实践利用公司服务器进行测试，采用1主+2从进行配置。系统均为CentOS7.5。
部署教程参考：https://blog.csdn.net/wo18237095579/article/details/86630750
k8s-master 192.168.199.120
k8s-node01 192.168.199.121
k8s-node02 192.168.199.115
### 运行步骤
#### 准备工作
##### 1、关闭防火墙
```
systemctl disable firewalld.service
systemctl stop firewalld.service
```
##### 2、禁用 Selinux
```
# 临时禁制
[root@kubeadm1 ~]# setenforce 0

# 永久禁止
[root@kubeadm1 ~]# vim /etc/selinux/config
SELINUX=disabled
```
##### 3、关闭swap
```
swapoff -a
```
##### 4、加入host
```
cat <<EOF > /etc/hosts
> 127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
> ::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
>
>192.168.199.120 k8s-master
>192.168.199.121 k8s-node01
>192.168.199.115 k8s-node02
> EOF
```
##### 5、安装docker
```
yum install -y docker
```
##### 6、安装`kubelet`、`kubeadm`、`kubectl`
```
yum install -y kubeadm kubelet-1.15.3 kubectl-1.15.3 --disableexcludes=kubernetes
systemctl enable kubelet && systemctl start kubelet
```
ps:安装失败可尝试更换yum源
```
cat << EOF >> /etc/yum.repos.d/kubernetes.repo
> [kubernetes]
> name=Kubernetes Repo
> baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64/
> gpgcheck=0
> gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg
> EOF
```
##### 7、配置kubectl
```
 echo "export KUBECONFIG=/etc/kubernetes/admin.conf" >> /etc/profile
 source /etc/profile 
 echo $KUBECONFIG
```
### master节点 配置
```
docker pull bingju328/kube-apiserverv1.15.3
docker pull mirrorgooglecontainers/kube-controller-manager:v1.15.3
docker pull mirrorgooglecontainers/kube-scheduler:v1.15.3
docker pull mirrorgooglecontainers/kube-proxy:v1.15.3
docker pull mirrorgooglecontainers/pause-amd64:3.1
docker pull richarddockerimage/etcd:latest
docker pull coredns/coredns:1.6.2

docker tag bingju328/kube-apiserverv1.15.3 k8s.gcr.io/kube-apiserver:v1.15.3
docker tag mirrorgooglecontainers/kube-controller-manager:v1.15.3 k8s.gcr.io/kube-controller-manager:v1.15.3
docker tag mirrorgooglecontainers/kube-scheduler:v1.15.3 k8s.gcr.io/kube-scheduler:v1.15.3
docker tag mirrorgooglecontainers/kube-proxy:v1.15.3 k8s.gcr.io/kube-proxy:v1.15.3
docker tag mirrorgooglecontainers/pause-amd64:3.1 k8s.gcr.io/pause:3.1
docker tag richarddockerimage/etcd:latest k8s.gcr.io/etcd:3.3.10
docker tag coredns/coredns:1.6.2 k8s.gcr.io/coredns:1.6.2

docker rmi bingju328/kube-apiserverv1.15.3
docker rmi mirrorgooglecontainers/kube-controller-manager:v1.15.3
docker rmi mirrorgooglecontainers/kube-scheduler:v1.15.3
docker rmi mirrorgooglecontainers/kube-proxy:v1.15.3
docker rmi mirrorgooglecontainers/pause-amd64:3.1
docker rmi richarddockerimage/etcd:latest
docker rmi coredns/coredns:1.6.2
```
#### 初始化主节点
##### 1、采用kubeadm的方式进行初始化
```
kubeadm init --kubernetes-version=v1.15.3 --apiserver-advertise-address 192.168.199.120 --apiserver-cert-extra-sans=123.57.57.175  --pod-network-cidr=10.244.0.0/16 --ignore-preflight-errors=NumCPU
```
##### 2、启动无误后，准备工作，方便 kubectl 连接
```
  mkdir -p $HOME/.kube
  sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
  sudo chown $(id -u):$(id -g) $HOME/.kube/config
```
##### 3、查看pod信息
```
kubectl get pods --all-namespaces -o wide
```
##### 4、查看节点信息
```
kubectl get nodes
```
#### 安装网络
Pod 网络是 Pod 之间进行通信的必要条件，k8s 支持很多种网络方案，在这里使用的是经典的 flannel 方案。
设置系统参数，使二层的网桥在转发包时也会被 iptables 的 FORWARD 规则所过滤。
```
cat <<EOF > /etc/sysctl.d/k8s.conf
> net.bridge.bridge-nf-call-ip6tables = 1
> net.bridge.bridge-nf-call-iptables = 1
> net.ipv4.ip_forward = 1
> vm.swappiness=0
> EOF

sysctl -p /etc/sysctl.conf
```
*  执行如下命令
```
 wget https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
 kubectl apply -f kube-flannel.yml
```
* 再次查看pod状态  从Pending变为Running即为成功！
```
kubectl get pods --all-namespaces -o wide
```
### 从节点配置
#### 1、加入主节点
```
kubeadm join 192.168.199.120:6443 --token 2pb40g.8n57cncki4giutn4 --discovery-token-ca-cert-hash sha256:1bf5f3190857d8edb7a91d93589d6cdb5c8737d55e8d36684ba03576cf6a5352
```
ps:错误日志的处理。这里如果出现文件已存在的一些错误信息，那么有可能是以前进行过 `join` 操作，没有清理掉。可以先使用命令 `kubeadm reset` 进行清理下，再进行 join 操作。
#### 2、在主节点查看从节点加入情况
```
kubectl get pods -n kube-system -o wide
kubectl get nodes
```
ps:稍等片刻，再去查看，Pods 状态为：`Running`，Nodes 状态为：`Ready`即为加入成功

### 拆卸集群
```
主节点运行
 kubectl drain <node name> --delete-local-data --force --ignore-daemonsets
 kubectl delete node <node name>

从节点运行
 kubeadm reset
 rm -rf /etc/kubernetes/
```
### 命令整理
|命令 | 作用 | 备注 |
| --- | --- | --- |
| kubeadm token list|查看token||
|https://www.cnblogs.com/lehuoxiong/p/9908357.html|查看cal hash||
| kubeadm init --kubernetes-version=v1.15.3 --apiserver-advertise-address 192.168.199.120 --pod-network-cidr=10.244.0.0/16 | 初始化 k8s 集群 |  |
| kubectl get pods --all-namespaces -o wide | 查看 Pods 信息。--all-namespaces 是指所有命名空间，也可以使用 -n kube-system 指定命名空间 |  |
 |kubectl get nodes |查看节点信息 | |
| kubectl apply -f kube-flannel.yaml| 安装 Pod 网络| |
|kubeadm join 192.168.199.120:6443 --token 2pb40g.8n57cncki4giutn4 --discovery-token-ca-cert-hash sha256:1bf5f3190857d8edb7a91d93589d6cdb5c8737d55e8d36684ba03576cf6a5352 |添加从节点 | |
|kubectl drain <node name> --delete-local-data --force --ignore-daemonsets |排除节点 | |
| kubectl delete node <node name>|删除节点 | |
|kubeadm reset |重置集群 | |
|kubectl describe pod <POD NAME> -n kube-system |查看 Pod 部署信息。排错使用 | |
|kubectl logs <POD NAME> -n kube-system |查看 Pod Log 信息。排错使用 | |
|kubectl cluster-info   systemctl status kubelet|查看状态||
|kubectl get pod kube-proxy-pjxw4 -n kube-system -o yaml / kubectl replace --force -f -|强制重启|将/替换为竖线|
|kubectl -n kube-system describe secret $(kubectl -n kube-system get secret / grep kubernetes-dashboard-admin-token / awk '{print $1}')|查看密码|将/替换为竖线|
 	
	
	
 	
 	

