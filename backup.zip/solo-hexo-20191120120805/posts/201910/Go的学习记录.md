title: Go的学习记录
date: '2019-10-24 17:04:03'
updated: '2019-10-24 17:09:36'
tags: [Golang, Go语言]
permalink: /articles/2019/10/24/1571907843673.html
---
[参考文档1：请点击](http://www.leewhich.cn:8787/book/Go%20%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0%20%E7%AC%AC%E5%9B%9B%E7%89%88.pdf)
[参考文档2：请点击](http://www.leewhich.cn:8787/book/Go%20%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0%20%E7%AC%AC%E5%85%AD%E7%89%88%20%E4%B8%8B%E5%8D%B7%20-%20%E9%A2%84%E8%A7%88.pdf)
