title: k8s部署实践（四）Rook-Ceph
date: '2019-11-19 00:24:51'
updated: '2019-11-19 00:25:10'
tags: [k8s, rook-ceph, ceph-dashboard]
permalink: /articles/2019/11/19/1574094291343.html
---
![](https://img.hacpai.com/bing/20180907.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 搭建Ceph-dashboard
#### 1、在Cluster.yaml中开启dashboard  
```
  spec:
    dashboard:
      enabled: true  #默认端口为8443
```
查看Service如下，默认为ClusterIp方式，只能内部节点访问
```
kubectl -n rook-ceph get service
NAME                         TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
rook-ceph-mgr                ClusterIP   10.108.111.192   <none>        9283/TCP         3h
rook-ceph-mgr-dashboard      ClusterIP   10.110.113.240   <none>        8443/TCP         3h
```
#### 2、现采用NodePort暴露节点Ip,新建Service，暴露Dashboard
```
apiVersion: v1
kind: Service
metadata:
  name: rook-ceph-mgr-dashboard-external-https
  namespace: rook-ceph
  labels:
    app: rook-ceph-mgr
    rook_cluster: rook-ceph
spec:
  ports:
  - name: dashboard  #可指定端口号
    port: 8443
    protocol: TCP
    targetPort: 8443
  selector:
    app: rook-ceph-mgr
    rook_cluster: rook-ceph
  sessionAffinity: None
  type: NodePort  #采用NodePort
```
执行后就会产生暴露的端口号
```
$ kubectl -n rook-ceph get service
NAME                                    TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
rook-ceph-mgr                           ClusterIP   10.108.111.192   <none>        9283/TCP         4h
rook-ceph-mgr-dashboard                 ClusterIP   10.110.113.240   <none>        8443/TCP         4h
rook-ceph-mgr-dashboard-external-https  NodePort    10.101.209.6     <none>        8443:31176/TCP   
```
#### 3、生成密码，用户名为admin
```
kubectl -n rook-ceph get secret rook-ceph-dashboard-password -o jsonpath='{.data.password}'  |  base64 --decode
```
#### 登录效果如下
![cephdashboard.png](https://img.hacpai.com/file/2019/11/cephdashboard-20f55c57.png)




