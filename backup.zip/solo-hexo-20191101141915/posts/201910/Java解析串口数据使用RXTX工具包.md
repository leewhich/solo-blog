title: Java解析串口数据（使用RXTX工具包）
date: '2019-10-15 14:37:03'
updated: '2019-10-15 14:38:24'
tags: [物联网, 串口, RXTX]
permalink: /articles/2019/10/15/1571121422881.html
---
### 一、配置环境
#### 1、下载并部署文件
官网下载rxfz文件，mfz-rxtx-2.2-20081207-win-x64

windows系统下

复制 RXTXcomm.jar ---> <JAVA_HOME>\jre\lib\ext

复制 rxtxSerial.dll ---> <JAVA_HOME>\jre\bin

复制 rxtxParallel.dll ---> <JAVA_HOME>\jre\bin

复制 rxtxSerial.dll 、rxtxParallel.dll到windows/system32

#### 2、设置串口参数：

连接设备（RS232转USB）--我的电脑--设备管理器--端口

查看端口号和设置波特率等

### 二、Java代码
#### 1、Main方法
```
public static void main(String[] args) {

    HashMap params = new HashMap();
    params.put(SerialReader.PARAMS_PORT, "COM4"); // 端口名称

    params.put(SerialReader.PARAMS_RATE, 9600); // 波特率

    params.put(SerialReader.PARAMS_TIMEOUT, 1000); // 设备超时时间 1秒

    params.put(SerialReader.PARAMS_DELAY, 200); // 端口数据准备时间 1秒

    params.put(SerialReader.PARAMS_DATABITS, SerialPort.DATABITS_8);// 数据位

     params.put(SerialReader.PARAMS_STOPBITS, SerialPort.STOPBITS_1); // 停止位

     params.put(SerialReader.PARAMS_PARITY, SerialPort.PARITY_NONE); // 无奇偶校验

    SerialReader sr = new SerialReader(params);
    CommDataObserver joe = new CommDataObserver("这是测试 ");
    sr.addObserver(joe);
}
```
#### 2、读取消息类SerialReader：
```
package com.tianzow.wl.serial;

import com.tianzow.wl.udp.NBServerHandler;
import gnu.io.*;
import io.netty.buffer.ByteBuf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import javax.management.AttributeList;
import java.io.IOException;
import java.io.InputStream;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.*;

/**
 * 串口数据读取类,用于windows的串口数据读取
 */

public class SerialReader extends Observable implements Runnable, SerialPortEventListener {

    private static Logger logger = LoggerFactory.getLogger(SerialReader.class);
    static CommPortIdentifier portId;

    int delayRead = 200;

    int numBytes; // buffer中的实际数据字节数

    private static byte[] readBuffer = new byte[4096]; // 4k的buffer空间,缓存串口读入的数据 static Enumeration portList;

    InputStream inputStream;

    SerialPort serialPort;

    HashMap serialParams;

    static List<String> PortList = null;
// 端口读入数据事件触发后,等待n毫秒后再读取,以便让数据一次性读完

    public static final String PARAMS_DELAY = "delay read"; // 延时等待端口数据准备的时间

    public static final String PARAMS_TIMEOUT = "timeout"; // 超时时间

    public static final String PARAMS_PORT = "port name"; // 端口名称

    public static final String PARAMS_DATABITS = "data bits"; // 数据位

    public static final String PARAMS_STOPBITS = "stop bits"; // 停止位

    public static final String PARAMS_PARITY = "parity"; // 奇偶校验

    public static final String PARAMS_RATE = "rate"; // 波特率


    /**
     * 初始化端口操作的参数.
     *
     * @see
     */

    public SerialReader(HashMap params) {

        serialParams = params;

        init();  //执行初始化操作

    }

    //向串口写数
    public  void WriteFromPort() {
        try {
            //获取串口的输出流对象
            OutputStream outputStream = serialPort.getOutputStream();
            //通过串口的输出流向串口写数据
            outputStream.write(new byte[]{'T'});
            outputStream.flush();
            //关闭输出流
            outputStream.close();
            System.out.println("发送数据1");
        } catch (Exception e) {
            logger.error("从串口写数据：" + e.getMessage(), e);
        }
    }

    private void init() {
        try {

// 参数初始化

            int timeout = Integer.parseInt(serialParams.get(PARAMS_TIMEOUT).toString());
            int rate = Integer.parseInt(serialParams.get(PARAMS_RATE).toString());

            int dataBits = Integer.parseInt(serialParams.get(PARAMS_DATABITS).toString());
            int stopBits = Integer.parseInt(serialParams.get(PARAMS_STOPBITS).toString());
            int parity = Integer.parseInt(serialParams.get(PARAMS_PARITY).toString());

            delayRead = Integer.parseInt(serialParams.get(PARAMS_DELAY).toString());

            String port = serialParams.get(PARAMS_PORT).toString();

// 打开端口

            portId = CommPortIdentifier.getPortIdentifier(port);

            serialPort = (SerialPort) portId.open("SerialReader", timeout);

            inputStream = serialPort.getInputStream();

            serialPort.addEventListener(this);

            serialPort.notifyOnDataAvailable(true);

            serialPort.setSerialPortParams(rate, dataBits, stopBits, parity);


        } catch (PortInUseException e) {
            System.out.println("端口已经被占用!");

            e.printStackTrace();

        } catch (TooManyListenersException e) {

            System.out.println("端口监听者过多!");

            e.printStackTrace();

        } catch (UnsupportedCommOperationException e) {

            System.out.println("端口操作命令不支持!");

            e.printStackTrace();

        } catch (NoSuchPortException e) {

            System.out.println("端口不存在!");

            e.printStackTrace();

        } catch (
                IOException e) {

            e.printStackTrace();

        }

        Thread readThread = new Thread(this);

        readThread.start();

    }

    public void run() {

        try {

            Thread.sleep(100);

        } catch (InterruptedException e) {

        }

    }


    public static String bytetoString(byte[] bytearray) {
        String result = "";
        char temp;

        int length = bytearray.length;
        for (int i = 0; i < length; i++) {
            temp = (char) bytearray[i];
            result += temp;
        }
        return result;
    }
    /**
     * Method declaration
     *
     * @param event
     * @see
     */

    public void serialEvent(SerialPortEvent event) {

        try {

// 等待1秒钟让串口把数据全部接收后在处理

            Thread.sleep(delayRead);

            //System.out.print("serialEvent[" + event.getSource() + "]");

        } catch (InterruptedException e) {

            e.printStackTrace();
        }

        switch (event.getEventType()) {
            case SerialPortEvent.BI: // 10 通讯中断
                System.err.println("与串口设备通讯中断");
                //WriteLog("与串口设备通讯中断","","");
                break;
            case SerialPortEvent.OE: // 7 溢位（溢出）错误
            case SerialPortEvent.FE: // 9 帧错误
            case SerialPortEvent.PE: // 8 奇偶校验错误
            case SerialPortEvent.CD: // 6 载波检测
            case SerialPortEvent.CTS: // 3 清除待发送数据
            case SerialPortEvent.DSR: // 4 待发送数据准备好了
            case SerialPortEvent.RI: // 5 振铃指示
            case SerialPortEvent.OUTPUT_BUFFER_EMPTY: // 2 输出缓冲区已清空
                break;
            case SerialPortEvent.DATA_AVAILABLE: // 1 串口存在可用数据
                byte[] data = null;
                try {
                    if (serialPort == null)
                    {
                        //WriteLog("串口对象为空！监听失败！", "", "");
                        System.err.println("串口对象为空！监听失败");
                    } else {
                        // 读取串口数据
                        data = readFromPort(serialPort);
                        String Portdata = null;
                        if(Portdata==null || Portdata.equals(""))
                            Portdata = new String(data,"ASCII");
                        else
                            Portdata += new String (data);
                        Portdata = Portdata.replaceAll("\r\n","");
                        String ShowPortdata = Portdata;
                        System.err.println("data="+Portdata);


                        //wn都存在
                        //wn00000.60kg
                        //存在此种情况只有w没有n：wn00000.60kgwn00000.60kgwn00000.60kgw00000.60kg0000.60kgw00000.60kgw00000.60kgw00000.60kgw00000.60kg
                        //此时去掉n后面的无效数据,重新获取n 和 k 的位置
                        if(Portdata!="")
                        {
                            int LastFirstGIndex = Portdata.lastIndexOf("g");
                            if(LastFirstGIndex>0)
                            {
                                Portdata = Portdata.substring(0, LastFirstGIndex);   //将末尾的不符合的数据截取掉
                                int LastFirstKIndex = Portdata.lastIndexOf("k");
                                if (LastFirstKIndex > 0) {
                                    String WeightTemp = Portdata.substring(LastFirstKIndex - 8, LastFirstKIndex);
                                    //WriteLog("WeightTemp="+WeightTemp, "", "");

                                    PortList.add(WeightTemp);
                                    String Weight = GetStableWeight();
                                    Portdata = "";  //取数成功后清空数据
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    System.err.println(e.toString());
                    //logger.error("处理监控到的串口事件：" + e.getMessage(), e);
                    // 发生读取错误时显示错误信息后退出系统
                }
                break;
        }
        //这是另一种解析方式
      /*  switch (event.getEventType()) {
            case SerialPortEvent.BI: // 10
            case SerialPortEvent.OE: // 7
            case SerialPortEvent.FE: // 9
            case SerialPortEvent.PE: // 8
            case SerialPortEvent.CD: // 6
            case SerialPortEvent.CTS: // 3
            case SerialPortEvent.DSR: // 4
            case SerialPortEvent.RI: // 5
            case SerialPortEvent.OUTPUT_BUFFER_EMPTY: // 2
                break;
            case SerialPortEvent.DATA_AVAILABLE: // 1
                try {
                // 多次读取,将所有数据读入
                // while (inputStream.available() > 0) {
                // numBytes = inputStream.read(readBuffer);
                // }
                    numBytes = inputStream.read(readBuffer);
                    changeMessage(readBuffer, numBytes);
                    //通知观察者
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
        }

        //定义用于缓存读入数据的数组
        byte[] cache = new byte[1024];
        //记录已经到达串口COM21且未被读取的数据的字节（Byte）数。
        int availableBytes = 0;
        //如果是数据可用的时间发送，则进行数据的读写
        if (event.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
            try {
                availableBytes = inputStream.available();
                while (availableBytes > 0) {
                    inputStream.read(cache);
                    for (int i = 0; i < cache.length && i < availableBytes; i++) {
                        //解码并输出数据
                        System.out.print((char) cache[i]);
                    }
                    availableBytes = inputStream.available();
                }
                System.out.println();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }*/

    }

    public static byte[] readFromPort(SerialPort serialPort) {
        InputStream in = null;
        byte[] bytes = null;
        byte[] bytesAll = new byte[100];
        int bytesLenght = 0;
        try {
            in = serialPort.getInputStream();
            try {
                // 获取buffer里的数据长度
                int bufflenth = in.available();
                while (bufflenth != 0) {
                    // 初始化byte数组为buffer中数据的长度
                    bytes = new byte[bufflenth];
                    in.read(bytes);
                    bufflenth = in.available();
                }
                //System.err.println("in.available="+in.available());
            }catch(Exception ex)
            {}
        } catch (IOException e) {
            //logger.error("从串口读取数据：" + e.getMessage(), e);
            //throw new ReadDataFromSerialPortFailure();
        } finally {
            try {
                if (in != null) {
                    in.close();
                    in = null;
                }
            } catch (IOException e) {
            }
        }
        return bytes;
    }

//获取稳定重量
private static String GetStableWeight()
{
    String RunWeight = "";
    //连续输出0时清空 PortList,防止内存溢出
    int PortLength = PortList.size();
    if(PortList.size()>10)
    {
        float OneNum = GetFloatNumber(PortList.get(PortLength - 11).toString());
        float TenNum = GetFloatNumber(PortList.get(PortLength-1).toString());
        //最后一个数减去倒数第十个数 变化小于1，表示数据稳定，然后取平均值 ，并清空PortList
        if(Math.abs(TenNum - OneNum)<1)
        {
            float AllWeight = 0;
            for(int i=0;i<10;i++)
            {
                AllWeight +=GetFloatNumber(PortList.get(PortLength - i-1).toString());
            }
            float WeightAvg = AllWeight/10.00f;
            RunWeight = String.valueOf(GetFloatNumber(String.valueOf(WeightAvg)));
            if(PortList.size()>100)
            {
                for(int i=0;i<50;i++)
                {
                    PortList.remove(i);
                }
            }
        }
    }
    return RunWeight;
}

    //将字符串转为float
    private static float GetFloatNumber(String fnum)
    {
        float ft = Float.valueOf(fnum);
        int scale  = 2;//设置位数
        int roundingMode  =  4;//表示四舍五入，可以选择其他舍值方式，例如去尾，等等.
        BigDecimal bd = new  BigDecimal((double)ft);
        bd = bd.setScale(scale,roundingMode);
        ft = bd.floatValue();
        return ft;
    }
    //将ASCII转化为字符串
    public static String asciiToString(String value)
    {
        StringBuffer sbu = new StringBuffer();
        String[] chars = value.split(",");
        for (int i = 0; i < chars.length; i++) {
            sbu.append((char) Integer.parseInt(chars[i]));
        }
        return sbu.toString();
    }



    // 通过observer pattern将收到的数据发送给observer
// 将buffer中的空字节删除后再发送更新消息,通知观察者
    public void changeMessage(byte[] message, int length) {
        setChanged();
        byte[] temp = new byte[length];
        System.arraycopy(message, 0, temp, 0, length);
        System.out.println("msg[" + numBytes + "]: [" + new String(temp) + "]");
        notifyObservers(temp);
    }


    static void listPorts() {
        Enumeration portEnum = CommPortIdentifier.getPortIdentifiers();
        while (portEnum.hasMoreElements()) {
            CommPortIdentifier portIdentifier = (CommPortIdentifier) portEnum.nextElement();
            System.out.println(portIdentifier.getName() + " - "
                    + getPortTypeName(portIdentifier.getPortType()));
        }
    }


    static String getPortTypeName(int portType) {
        switch (portType) {
            case CommPortIdentifier.PORT_I2C:
                return "I2C";
            case CommPortIdentifier.PORT_PARALLEL:
                return "Parallel";
            case CommPortIdentifier.PORT_RAW:
                return "Raw";
            case CommPortIdentifier.PORT_RS485:
                return "RS485";
            case CommPortIdentifier.PORT_SERIAL:
                return "Serial";
            default:
                return "unknown type";
        }
    }

    /**
     * @return A HashSet containing the CommPortIdentifier for all serial ports that are not
     * currently being used.
     */
    public static HashSet<CommPortIdentifier> getAvailableSerialPorts() {
        HashSet<CommPortIdentifier> h = new HashSet<CommPortIdentifier>();
        Enumeration thePorts = CommPortIdentifier.getPortIdentifiers();
        while (thePorts.hasMoreElements()) {
            CommPortIdentifier com = (CommPortIdentifier) thePorts.nextElement();
            switch (com.getPortType()) {
                case CommPortIdentifier.PORT_SERIAL:
                    try {
                        CommPort thePort = com.open("CommUtil", 50);
                        thePort.close();
                        h.add(com);
                    } catch (PortInUseException e) {


                        System.out.println("Port, " + com.getName() + ", is in use.");


                    } catch (Exception e) {
                        System.out.println("Failed to open port " + com.getName() + e);
                    }
            }
        }
        return h;
    }
}
```
#### 3、观察者，当读到消息调用notifyObservers方法时会被通知到
```
package com.tianzow.wl.serial;

import java.util.Observable;

import java.util.Observer;

  
public class CommDataObserver implements Observer {

String name;

public CommDataObserver(String name) {

this.name = name;

}


public void update(Observable o, Object arg) {

System.out.println("[" + name + "] GetMessage:\n [" + new String((byte[]) arg) + "]");

}

}
```
