title: 安装Docker镜像仓库Harbor(二)k8s拉取本地Harbor镜像
date: '2019-11-15 09:33:17'
updated: '2019-11-15 09:33:17'
tags: [harbor, k8s]
permalink: /articles/2019/11/15/1573781597154.html
---
#### 创建secret对象
```
kubectl create secret docker-registry registry-secret --namespace=default \
--docker-server=http://192.168.199.121:5000 --docker-username=admin\
--docker-password=Harbor12345
```
#### 在创建对象中使用上面得secretd对象
```
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-deployment
spec:
  selector:
    matchLabels:
      app: nginx
  replicas: 2
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: 192.168.199.121:5000/tianzow/dingding-nginx:latest
        ports:
        - containerPort: 80
      imagePullSecrets:
      - name: registry-secret

```
