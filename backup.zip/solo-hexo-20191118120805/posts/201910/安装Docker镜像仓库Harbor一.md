title: 安装Docker镜像仓库Harbor(一)
date: '2019-10-15 14:42:23'
updated: '2019-11-15 09:13:20'
tags: [Docker, Harbor, 镜像仓库]
permalink: /articles/2019/10/15/1571121743523.html
---
### 安装Harbor

  

#### 安装1.7.5版本的，高版本有问题

通过docke-compose 启动harbor ./install.sh

  

#### 修改https连接问题

vi /etc/docker/daemon.json

{"insecure-registries":["192.168.199.121:5000"]}

systemctl restart docker.service

  

  

vi /usr/lib/systemd/system/docker.service

  

docker login 192.168.199.121:5000 admin/tianzow

  

  

#### 打标签 d

docker tag SOURCE_IMAGE[:TAG] 61.188.209.10:7788/tianzow_springcloud/IMAGE[:TAG]

推送 docker push 192.168.199.121:5000/library/IMAGE[:TAG]

拉下来 docker pull 192.168.199.121:5000/pinpoint/pinppoint-agent:1.8.4

#### 运行

run --name tianzow-eureka -p 8761:8761 -d 61.188.209.10:7788/tianzow_springcloud/tianzow-eureka:1.0.0

#### SVN+更新Harbor

1.SVN拉下 Dockerfile 和 jar 包

svn co http://erp.tianzow.com:9900/svn/tzcode/pro_jar/Dockerfiles/tianzow-eureka --username lwq --password lwq

2.打包镜像

cd 文件目录

docker build -t tianzow-eureka .

3.登录Harbor

docker login 61.188.209.10:7788

本机127.0.0.1：80

admin/tianzow

4.打镜像标签

docker tag SOURCE_IMAGE[:TAG] 61.188.209.10:7788/tianzow_springcloud/IMAGE[:TAG]

5.推送

推送 docker push 61.188.209.10:7788/library/IMAGE[:TAG]

拉下来 docker pull 61.188.209.10:7788/pinpoint/pinppoint-agent:1.8.4

6、运行

docker run --name eureka -p 8761:8761 -d 127.0.0.1:80/tianzow_springcloud/tianzow-eureka:1.0.0

7、查看运行日志

docker logs -f -t --tail 条数 容器ID/容器名
