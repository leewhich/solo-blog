title: linux部署图片服务器
date: '2019-10-15 13:12:37'
updated: '2019-10-15 22:41:33'
tags: [linux, node.js, 图片服务器]
permalink: /articles/2019/10/15/1571116356851.html
---
![](https://img.hacpai.com/bing/20190312.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

linux 安装图片服务器（通过node运行 http-server)

docker pull node

docker run -i -t --name node -p 8787:8787 -d -v /opt/dingding/share:/opt/share node /bin/bash

进入容器

docker exec -it XXXXXX /bin/bash

npm install -g http-server

进入指定目录

cd XXXX

http-server -p 8787
效果如下

![clipboard.png](https://img.hacpai.com/file/2019/10/clipboard-561ae141.png)

